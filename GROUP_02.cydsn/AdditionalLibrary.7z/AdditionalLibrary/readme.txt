Library:
   AdditionalLibrary: RGB LED common cathode + TMP36GZ 

Component Library location:
   .\AdditionalLibrary_lib\AdditionalLibrary_lib.cylib

Description:
   Implements off-chip components (RGB LED common cathode and TMP36GZ) in order to add them to the TopDesign of the Assigment to improve the understanding of the overall schematic 
